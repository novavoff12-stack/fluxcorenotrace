import { LayoutDashboard, Users, Settings, LogOut, Menu, Clock, Code, Megaphone, CalendarDays, Sun, Moon, FileText, CalendarOff, UserX, Target, ShieldCheck, DoorOpen, BadgeCheck, MessageSquare, Sparkles, Trophy, Heart, ArrowUp, ClipboardList } from "lucide-react";
import { useEffect, useState } from "react";
import { useUIVersion } from "@/hooks/useUIVersion";
import { NavLink } from "@/components/NavLink";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useWorkspace } from "@/hooks/useWorkspace";
import { usePermissions } from "@/hooks/usePermissions";
import { useTheme } from "@/hooks/useTheme";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { isPortalHost } from "@/lib/sso";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarFooter, useSidebar,
} from "@/components/ui/sidebar";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const navigate = useNavigate();
  const { signOut, user } = useAuth();
  const { workspaceId, workspace, isOwner } = useWorkspace();
  const { hasPermission } = usePermissions();
  const { theme, toggleTheme } = useTheme();
  const { setVersion } = useUIVersion();
  const [leaderboardOn, setLeaderboardOn] = useState(false);

  useEffect(() => {
    if (!workspaceId) return;
    let cancelled = false;
    supabase
      .from("workspaces")
      .select("leaderboard_categories")
      .eq("id", workspaceId)
      .maybeSingle()
      .then(({ data }) => {
        if (cancelled) return;
        const cats = ((data as any)?.leaderboard_categories || []) as string[];
        setLeaderboardOn(cats.length > 0);
      });
    return () => { cancelled = true; };
  }, [workspaceId]);

  const base = `/w/${workspaceId}`;

  const mainItems = [
    { title: "Dashboard", url: `${base}/dashboard`, icon: LayoutDashboard, show: true },
    { title: "Members", url: `${base}/members`, icon: Users, show: true },
    { title: "Activity", url: `${base}/activity`, icon: Clock, show: hasPermission("view_activity") },
    { title: "Sessions", url: `${base}/sessions`, icon: CalendarDays, show: true },
    { title: "Leaderboard", url: `${base}/leaderboard`, icon: Trophy, show: leaderboardOn },
    { title: "Wall", url: `${base}/wall`, icon: Megaphone, show: true },
    { title: "Kudos", url: `${base}/kudos`, icon: Heart, show: true },
    { title: "Promotions", url: `${base}/promotions`, icon: ArrowUp, show: true },
    { title: "Applications", url: `${base}/applications`, icon: ClipboardList, show: isOwner || hasPermission("manage_applications") },
    { title: "Documents", url: `${base}/documents`, icon: FileText, show: true },
    { title: "LOA", url: `${base}/loa`, icon: CalendarOff, show: true },
    { title: "Staff", url: `${base}/staff`, icon: UserX, show: isOwner || hasPermission("manage_members") },
    { title: "Quotas", url: `${base}/quotas`, icon: Target, show: true },
    { title: "Message Logs", url: `${base}/message-logs`, icon: MessageSquare, show: isOwner || hasPermission("view_message_logs") },
  ];

  const showConfig = isOwner || hasPermission("view_config");
  const configItems = [
    { title: "Roles", url: `${base}/roles`, icon: ShieldCheck },
    { title: "Settings", url: `${base}/settings`, icon: Settings },
  ];

  const handleLogout = async () => {
    await signOut();
    navigate("/login");
  };

  const handleLeaveWorkspace = async () => {
    if (!user) return;
    const { error } = await supabase
      .from("workspace_members")
      .delete()
      .eq("workspace_id", workspaceId)
      .eq("user_id", user.id);
    if (error) toast.error("Failed to leave workspace");
    else {
      toast.success("You have left the workspace");
      navigate("/workspaces");
    }
  };

  return (
    <Sidebar collapsible="icon" className="border-r border-border/40">
      <SidebarContent>
        <SidebarGroup>
          <div className="px-4 py-5 mb-1">
            {!collapsed ? (
              <div>
                <button onClick={() => navigate("/")} className="text-lg font-extrabold text-gradient tracking-tight hover:opacity-80 transition-opacity">
                  Fluxcore
                </button>
                {workspace && (
                  <p className="text-[10px] text-muted-foreground truncate mt-0.5 flex items-center gap-1">
                    <span className="truncate">{workspace.name}</span>
                    {workspace.verified_official && <BadgeCheck className="w-3 h-3 text-primary shrink-0" aria-label="Official verified group" />}
                  </p>
                )}
              </div>
            ) : (
              <button onClick={() => navigate("/")} className="text-lg font-extrabold text-primary hover:opacity-80 transition-opacity">
                F
              </button>
            )}
          </div>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainItems.filter(i => i.show).map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end className="hover:bg-secondary/60" activeClassName="bg-primary/10 text-primary font-semibold">
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {showConfig && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-xs text-muted-foreground/70 px-4 uppercase tracking-widest">
              {!collapsed && "Config"}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {configItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink to={item.url} end className="hover:bg-secondary/60" activeClassName="bg-primary/10 text-primary font-semibold">
                        <item.icon className="mr-2 h-4 w-4" />
                        {!collapsed && <span>{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={() => setVersion("nexus")} className="text-muted-foreground hover:bg-secondary/60 hover:text-foreground">
              <Sparkles className="mr-2 h-4 w-4" />
              {!collapsed && <span>Switch to Nexus UI</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={() => setVersion("minimal")} className="text-muted-foreground hover:bg-secondary/60 hover:text-foreground">
              <Sparkles className="mr-2 h-4 w-4" />
              {!collapsed && <span>Try Fluxcore New UI</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>

          <SidebarMenuItem>
            <SidebarMenuButton onClick={toggleTheme} className="text-muted-foreground hover:bg-secondary/60 hover:text-foreground">
              {theme === "dark" ? <Sun className="mr-2 h-4 w-4" /> : <Moon className="mr-2 h-4 w-4" />}
              {!collapsed && <span>{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
          {!isPortalHost() && (
          <SidebarMenuItem>
            <SidebarMenuButton onClick={() => navigate("/workspaces")} className="text-muted-foreground hover:bg-secondary/60 hover:text-foreground">
              <Menu className="mr-2 h-4 w-4" />
              {!collapsed && <span>Switch Workspace</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
          )}
          {!isOwner && (
            <SidebarMenuItem>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <SidebarMenuButton className="text-warning/80 hover:bg-warning/10 hover:text-warning">
                    <DoorOpen className="mr-2 h-4 w-4" />
                    {!collapsed && <span>Leave Workspace</span>}
                  </SidebarMenuButton>
                </AlertDialogTrigger>
                <AlertDialogContent className="glass border-border/40">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Leave Workspace?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to leave {workspace?.name}? You'll need a new invite to rejoin.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>No, stay</AlertDialogCancel>
                    <AlertDialogAction onClick={handleLeaveWorkspace} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Yes, leave
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </SidebarMenuItem>
          )}
          <SidebarMenuItem>
            <SidebarMenuButton onClick={handleLogout} className="text-destructive/80 hover:bg-destructive/10 hover:text-destructive">
              <LogOut className="mr-2 h-4 w-4" />
              {!collapsed && <span>Logout</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
