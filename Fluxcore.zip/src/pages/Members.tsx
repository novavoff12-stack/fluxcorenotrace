import { DashboardLayout } from "@/components/DashboardLayout";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RobloxAvatar } from "@/components/RobloxAvatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Search, Crown, ChevronLeft, ChevronRight, Copy, Users as UsersIcon, ArrowUpDown } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { BulkActionBar, type BulkAction } from "@/components/BulkActionBar";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/hooks/useWorkspace";
import { usePermissions } from "@/hooks/usePermissions";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

interface Member {
  id: string;
  roblox_username: string;
  roblox_user_id: string;
  role: string;
  role_id: string | null;
  verified: boolean;
  joined_at: string;
  user_id: string | null;
  roblox_group_rank?: number | null;
}

interface RobloxGroupRole {
  id: string;
  displayName: string;
  rank: number;
}

const PAGE_SIZE = 15;

export default function Members() {
  const { workspaceId, workspace, isOwner } = useWorkspace();
  const { hasPermission } = usePermissions();
  const { robloxUsername } = useAuth();
  const navigate = useNavigate();
  const [members, setMembers] = useState<Member[]>([]);
  const [avatars, setAvatars] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [warningCounts, setWarningCounts] = useState<Record<string, number>>({});
  const [minutesCounts, setMinutesCounts] = useState<Record<string, number>>({});
  const [roles, setRoles] = useState<{id: string; name: string; color: string}[]>([]);

  // Rank dialog
  const [rankDialogOpen, setRankDialogOpen] = useState(false);
  const [rankTarget, setRankTarget] = useState<Member | null>(null);
  const [robloxGroupRoles, setRobloxGroupRoles] = useState<RobloxGroupRole[]>([]);
  const [selectedRobloxRole, setSelectedRobloxRole] = useState("");
  const [rankLoading, setRankLoading] = useState(false);
  const [rankFetchLoading, setRankFetchLoading] = useState(false);

  // Bulk selection
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const canManage = isOwner || hasPermission("manage_members");
  const canEditRoles = isOwner || hasPermission("edit_roles");
  const canPromote = isOwner || hasPermission("promote_members");
  const canDemote = isOwner || hasPermission("demote_members");
  const canAnyBulk = canManage || canEditRoles || canPromote || canDemote;

  const fetchMembers = async () => {
    const { data } = await supabase
      .from("workspace_members")
      .select("*")
      .eq("workspace_id", workspaceId)
      .order("joined_at", { ascending: true });

    let membersList = data || [];

    if (workspace) {
      const { data: ownerData } = await supabase
        .from("verified_users")
        .select("roblox_username, roblox_user_id")
        .eq("user_id", workspace.owner_id)
        .maybeSingle();

      // Deduplicate: Roblox's 2026 update lets any rank be named "Owner" and any user hold rank 255,
      // so we identify the true owner by workspace.owner_id / their verified roblox_user_id and
      // strip any duplicate rows that the group-sync may have imported for that same person.
      if (ownerData) {
        membersList = membersList.filter(
          (m) => m.user_id !== workspace.owner_id
              && String(m.roblox_user_id) !== String(ownerData.roblox_user_id),
        );
        membersList.unshift({
          id: "owner-virtual", roblox_username: ownerData.roblox_username,
          roblox_user_id: ownerData.roblox_user_id, role: "Owner",
          role_id: null, verified: true, joined_at: new Date().toISOString(), user_id: workspace.owner_id,
        } as any);
      } else {
        membersList = membersList.filter((m) => m.user_id !== workspace.owner_id);
      }
    }

    setMembers(membersList);

    const memberIds = membersList.filter(m => m.id !== "owner-virtual").map(m => m.id);
    if (memberIds.length > 0) {
      const { data: logs } = await supabase.from("member_logs").select("member_id, log_type")
        .eq("workspace_id", workspaceId).eq("log_type", "warning");
      const wCounts: Record<string, number> = {};
      (logs || []).forEach(l => { wCounts[l.member_id] = (wCounts[l.member_id] || 0) + 1; });
      setWarningCounts(wCounts);
    }

    const robloxIds = membersList.map(m => m.roblox_user_id);
    if (robloxIds.length > 0) {
      const { data: sessions } = await supabase.from("activity_sessions")
        .select("roblox_user_id, duration_seconds").eq("workspace_id", workspaceId);
      const mCounts: Record<string, number> = {};
      (sessions || []).forEach(s => { mCounts[s.roblox_user_id] = (mCounts[s.roblox_user_id] || 0) + (s.duration_seconds || 0); });
      setMinutesCounts(mCounts);
    }

    // Fetch workspace roles
    const { data: rolesData } = await supabase.from("workspace_roles").select("id, name, color")
      .eq("workspace_id", workspaceId).order("position");
    setRoles(rolesData || []);

    setLoading(false);

    if (membersList.length > 0) {
      const userIds = membersList.map(m => m.roblox_user_id).join(",");
      try {
        const res = await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userIds}&size=48x48&format=Png&isCircular=true`);
        const json = await res.json();
        const map: Record<string, string> = {};
        if (json?.data) for (const item of json.data) if (item.imageUrl) map[item.targetId.toString()] = item.imageUrl;
        setAvatars(map);
      } catch {}
    }
  };

  useEffect(() => { fetchMembers(); }, [workspaceId]);

  const openRankDialog = async (member: Member) => {
    setRankTarget(member);
    setRankDialogOpen(true);
    setRankFetchLoading(true);
    setRobloxGroupRoles([]);
    setSelectedRobloxRole("");

    try {
      const res = await supabase.functions.invoke("roblox-rank", {
        body: { action: "get_roles", workspace_id: workspaceId },
      });
      if (res.data?.roles) {
        setRobloxGroupRoles(res.data.roles.map((r: any) => ({
          id: r.id?.split("/").pop() || r.id,
          displayName: r.displayName || r.name || `Rank ${r.rank}`,
          rank: r.rank || 0,
        })).sort((a: any, b: any) => b.rank - a.rank));
      } else {
        toast.error(res.data?.error || "Failed to fetch group roles");
      }
    } catch (e: any) {
      toast.error("Error: " + e.message);
    }
    setRankFetchLoading(false);
  };

  const doRank = async () => {
    if (!rankTarget || !selectedRobloxRole) return;
    setRankLoading(true);
    try {
      const res = await supabase.functions.invoke("roblox-rank", {
        body: { action: "set_rank", workspace_id: workspaceId, roblox_user_id: rankTarget.roblox_user_id, role_id: selectedRobloxRole },
      });
      if (res.data?.success) {
        const roleName = robloxGroupRoles.find(r => r.id === selectedRobloxRole)?.displayName || selectedRobloxRole;
        toast.success(`Successfully ranked ${rankTarget.roblox_username} to ${roleName}!`);
        // Log the rank change
        if (rankTarget.id !== "owner-virtual") {
          await supabase.from("member_logs").insert({
            workspace_id: workspaceId,
            member_id: rankTarget.id,
            author_id: (await supabase.auth.getUser()).data.user?.id || "",
            author_name: robloxUsername || "Unknown",
            log_type: "rank_change",
            content: `Ranked to ${roleName} in Roblox group`,
          });
          // Two-way sync: update Fluxcore role to match the Roblox role mapping
          await supabase.functions.invoke("roblox-sync-rank", {
            body: { action: "sync_member", workspace_id: workspaceId, member_id: rankTarget.id },
          });
        }
        setRankDialogOpen(false);
        fetchMembers();
      } else {
        toast.error(res.data?.error || "Failed to change rank");
      }
    } catch (e: any) {
      toast.error("Error: " + e.message);
    }
    setRankLoading(false);
  };

  const filtered = members.filter(m => m.roblox_username.toLowerCase().includes(search.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const copyUsername = (name: string, e: React.MouseEvent) => { e.stopPropagation(); navigator.clipboard.writeText(name); toast.success("Copied!"); };

  const getRoleColor = (roleId: string | null) => {
    if (!roleId) return undefined;
    const role = roles.find(r => r.id === roleId);
    return role?.color;
  };

  const selectableMembers = members.filter(m => m.id !== "owner-virtual" && m.role !== "Owner");
  const pageSelectable = paged.filter(m => m.id !== "owner-virtual" && m.role !== "Owner");
  const allPageSelected = pageSelectable.length > 0 && pageSelectable.every(m => selected.has(m.id));

  const toggleOne = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAllOnPage = () => {
    setSelected(prev => {
      const next = new Set(prev);
      if (allPageSelected) pageSelectable.forEach(m => next.delete(m.id));
      else pageSelectable.forEach(m => next.add(m.id));
      return next;
    });
  };

  const runBulk = async (action: BulkAction, payload?: { roleId?: string; reason?: string }) => {
    const ids = [...selected];
    const targets = members.filter(m => ids.includes(m.id));
    if (targets.length === 0) return;
    const authorName = robloxUsername || "Unknown";
    const authorId = (await supabase.auth.getUser()).data.user?.id || "";

    let ok = 0, fail = 0;

    if (action === "remove") {
      for (const m of targets) {
        const { error } = await supabase.from("workspace_members").delete().eq("id", m.id);
        if (error) fail++; else ok++;
      }
    } else if (action === "assign_role") {
      for (const m of targets) {
        const { error } = await supabase.from("workspace_members").update({ role_id: payload?.roleId || null }).eq("id", m.id);
        if (error) { fail++; continue; }
        await supabase.from("member_logs").insert({
          workspace_id: workspaceId, member_id: m.id, author_id: authorId, author_name: authorName,
          log_type: "role_change",
          content: `Assigned role ${roles.find(r => r.id === payload?.roleId)?.name || "(unknown)"} via bulk action`,
        });
        ok++;
      }
    } else if (action === "warn") {
      for (const m of targets) {
        const { error } = await supabase.from("member_logs").insert({
          workspace_id: workspaceId, member_id: m.id, author_id: authorId, author_name: authorName,
          log_type: "warning", content: payload?.reason || "Bulk warning",
        });
        if (error) fail++; else ok++;
      }
    } else if (action === "promote" || action === "demote") {
      // Rank one step in the Roblox group: fetch group roles once, find each member's current rank, move ±1.
      const res = await supabase.functions.invoke("roblox-rank", {
        body: { action: "get_roles", workspace_id: workspaceId },
      });
      const groupRoles = ((res.data?.roles || []) as any[])
        .map(r => ({ id: (r.id?.split("/").pop() || r.id) as string, rank: r.rank || 0, name: r.displayName || r.name || "" }))
        .sort((a, b) => a.rank - b.rank);
      if (groupRoles.length === 0) {
        toast.error("Couldn't load Roblox group roles");
        return;
      }
      for (const m of targets) {
        const currentRank = m.roblox_group_rank ?? null;
        const idx = currentRank == null ? -1 : groupRoles.findIndex(r => r.rank === currentRank);
        const targetIdx = action === "promote" ? idx + 1 : idx - 1;
        if (idx < 0 || targetIdx < 0 || targetIdx >= groupRoles.length) { fail++; continue; }
        const targetRole = groupRoles[targetIdx];
        const rankRes = await supabase.functions.invoke("roblox-rank", {
          body: { action: "set_rank", workspace_id: workspaceId, roblox_user_id: m.roblox_user_id, role_id: targetRole.id },
        });
        if (rankRes.data?.success) {
          ok++;
          await supabase.from("member_logs").insert({
            workspace_id: workspaceId, member_id: m.id, author_id: authorId, author_name: authorName,
            log_type: "rank_change", content: `${action === "promote" ? "Promoted" : "Demoted"} to ${targetRole.name} via bulk action`,
          });
        } else fail++;
      }
    }

    if (ok > 0) toast.success(`${ok} member${ok === 1 ? "" : "s"} updated${fail ? ` — ${fail} failed` : ""}`);
    else toast.error(`Bulk action failed (${fail} errors)`);
    setSelected(new Set());
    fetchMembers();
  };

  if (loading) {
    return <DashboardLayout title="Members"><div className="flex justify-center py-20"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div></DashboardLayout>;
  }

  return (
    <DashboardLayout title="Members">
      <div className="space-y-5 max-w-5xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Staff Management</h1>
            <p className="text-sm text-muted-foreground mt-0.5">View and manage your staff members</p>
          </div>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            {canManage && (
              <Button variant="outline" size="sm" onClick={async () => {
                toast.loading("Syncing ranks from Roblox...", { id: "sync" });
                const res = await supabase.functions.invoke("roblox-sync-rank", {
                  body: { action: "sync_all", workspace_id: workspaceId },
                });
                toast.dismiss("sync");
                if (res.data?.success) {
                  toast.success(`Synced ${res.data.synced}/${res.data.total} members`);
                  fetchMembers();
                } else {
                  toast.error(res.data?.error || "Sync failed");
                }
              }}>
                <ArrowUpDown className="w-3 h-3 mr-1" /> Sync from Roblox
              </Button>
            )}
            <span className="flex items-center gap-1"><UsersIcon className="w-4 h-4" /> {members.length} members</span>
          </div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search members..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 bg-muted border-border" />
          </div>
        </div>

        <div className="glass rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50">
                  {canManage && (
                    <th className="w-10 px-3 py-3">
                      <Checkbox
                        checked={allPageSelected}
                        onCheckedChange={toggleAllOnPage}
                        aria-label="Select all on page"
                      />
                    </th>
                  )}
                  <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">User</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Rank</th>
                  <th className="text-center px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Warnings</th>
                  <th className="text-center px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Minutes</th>
                  {canManage && <th className="text-center px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40">
                {paged.map(member => {
                  const selectable = member.id !== "owner-virtual" && member.role !== "Owner";
                  return (
                  <tr key={member.id} onClick={() => { if (member.id !== "owner-virtual") navigate(`/w/${workspaceId}/members/${member.id}`); }} className="hover:bg-secondary/30 transition-colors cursor-pointer">
                    {canManage && (
                      <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                        {selectable && (
                          <Checkbox
                            checked={selected.has(member.id)}
                            onCheckedChange={() => toggleOne(member.id)}
                            aria-label={`Select ${member.roblox_username}`}
                          />
                        )}
                      </td>
                    )}
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <RobloxAvatar
                          username={member.roblox_username}
                          userId={member.roblox_user_id}
                          className="w-9 h-9 rounded-full"
                        />
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-foreground">{member.roblox_username}</span>
                          {member.role === "Owner" && <Crown className="w-3.5 h-3.5 text-warning" />}
                          {member.verified && <span className="w-2 h-2 rounded-full bg-success" title="Verified" />}
                          <button onClick={(e) => copyUsername(member.roblox_username, e)} className="text-muted-foreground hover:text-foreground transition-colors">
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span className="text-xs px-2 py-1 rounded-full font-medium" style={{
                        backgroundColor: getRoleColor(member.role_id) ? `${getRoleColor(member.role_id)}20` : undefined,
                        color: getRoleColor(member.role_id) || undefined,
                      }}>
                        {member.role}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-center">
                      <span className="text-sm text-foreground">{warningCounts[member.id] || 0}</span>
                    </td>
                    <td className="px-5 py-3 text-center">
                      <span className="text-sm text-foreground">{Math.round((minutesCounts[member.roblox_user_id] || 0) / 60)}</span>
                    </td>
                    {canManage && (
                      <td className="px-5 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                        {member.id !== "owner-virtual" && (
                          <div className="flex items-center justify-center gap-1">
                            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => openRankDialog(member)}>
                              <ArrowUpDown className="w-3 h-3 mr-1" /> Rank
                            </Button>
                          </div>
                        )}
                      </td>
                    )}
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between px-5 py-3 border-t border-border/50">
              <span className="text-xs text-muted-foreground">Page {page + 1} of {totalPages}</span>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" disabled={page === 0} onClick={() => setPage(p => p - 1)}><ChevronLeft className="w-4 h-4" /></Button>
                <Button variant="ghost" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}><ChevronRight className="w-4 h-4" /></Button>
              </div>
            </div>
          )}
        </div>

        <BulkActionBar
          selectedCount={selected.size}
          roles={roles}
          canManage={canManage}
          canEditRoles={canEditRoles}
          canPromote={canPromote}
          canDemote={canDemote}
          onClear={() => setSelected(new Set())}
          onRun={runBulk}
        />
      </div>

      {/* Rank Dialog */}
      <Dialog open={rankDialogOpen} onOpenChange={setRankDialogOpen}>
        <DialogContent className="glass border-border/40 max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-foreground">Change Rank — {rankTarget?.roblox_username}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <p className="text-xs text-muted-foreground">Select the Roblox group role to assign. This will promote or demote them in your Roblox group.</p>
            {rankFetchLoading ? (
              <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 text-primary animate-spin" /></div>
            ) : robloxGroupRoles.length === 0 ? (
              <p className="text-sm text-destructive text-center py-4">No roles found. Check your Roblox API key and Group ID in Settings.</p>
            ) : (
              <Select value={selectedRobloxRole} onValueChange={setSelectedRobloxRole}>
                <SelectTrigger className="bg-muted border-border"><SelectValue placeholder="Select a role..." /></SelectTrigger>
                <SelectContent>
                  {robloxGroupRoles.map(r => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.displayName} (Rank {r.rank})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Button variant="hero" className="w-full" onClick={doRank} disabled={rankLoading || !selectedRobloxRole}>
              {rankLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Confirm Rank Change
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
