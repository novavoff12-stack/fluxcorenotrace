
import { useNavigate } from "react-router-dom";
import nexusDemoShot from "@/assets/nexus-demo-dashboard.jpg";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import {
  ArrowRight,
  Sun,
  Moon,
  Activity,
  Calendar,
  Shield,
  FileSignature,
  Users,
  MessageSquare,
  Plane,
  Target,
  Megaphone,
  KeyRound,
  Zap,
  LayoutDashboard,
  Clock,
  CalendarDays,
  FileText,
  CalendarOff,
  UserX,
  ShieldCheck,
  Code,
  Settings,
  BadgeCheck,
  type LucideIcon,
} from "lucide-react";
import { WorkspaceMarquee } from "@/components/WorkspaceMarquee";

import { SiteBanner } from "@/components/SiteBanner";
import { Wordmark } from "@/components/Wordmark";
import { useIsMobile } from "@/hooks/use-mobile";
import bloxyBargainsBadge from "@/assets/bloxy-bargains-badge.png";
import redFunnelBadge from "@/assets/red-funnel-badge.png";

/* ---------------------------------------------------------------------------
   Fluxcore homepage — rounded, human, product-first.
   Inter headings and body, one violet accent, no AI clichés.
--------------------------------------------------------------------------- */

export default function LandingClassic() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const isLoggedIn = !authLoading && !!user;
  const isMobile = useIsMobile();

  const go = () => navigate(isLoggedIn ? "/workspaces" : "/login");

  const capabilities = [
    { icon: Activity, title: "Activity tracking", desc: "A heartbeat every 30 seconds, idle detection included. You always know who is in-game and for how long." },
    { icon: Shield, title: "Group ranking", desc: "Promote and demote from the dashboard. Writes straight back to your Roblox group over Open Cloud." },
    { icon: Calendar, title: "Sessions & shifts", desc: "Trainings, patrols, flights. Staff claim their own slots and Discord gets the reminder." },
    { icon: Target, title: "Per-role quotas", desc: "Weekly session and time targets per rank. Reset weekly, monthly, or never." },
    { icon: FileSignature, title: "Policies & signatures", desc: "Write the handbook once, require sign-off, auto-assign it to everyone who joins." },
    { icon: Users, title: "Roles & permissions", desc: "Import ranks from Roblox, then split permissions down to promote vs. demote." },
    { icon: MessageSquare, title: "Message logs", desc: "Every staff chat line in-game, searchable. Moderation stops being a guessing game." },
    { icon: Plane, title: "Leave of absence", desc: "Requests in, approvals in one click, quotas adjust themselves while people are away." },
    { icon: Megaphone, title: "Staff wall", desc: "Announcements that people actually read, instead of a seventh Discord channel." },
    { icon: BadgeCheck, title: "Warnings & history", desc: "Warnings, promotions and notes stay on the profile, so handovers take five minutes." },
    { icon: KeyRound, title: "Open Cloud API", desc: "Your group key, your ranking. No bot account sitting in the group doing the work." },
    { icon: Zap, title: "Discord webhooks", desc: "Reminders, rank changes and alerts routed to the channels your team already watches." },
  ];

  const rail = [
    { icon: LayoutDashboard, label: "Dashboard" },
    { icon: Users, label: "Members" },
    { icon: Clock, label: "Activity" },
    { icon: CalendarDays, label: "Sessions" },
    { icon: Megaphone, label: "Wall" },
    { icon: FileText, label: "Documents" },
    { icon: CalendarOff, label: "LOA" },
    { icon: UserX, label: "Staff" },
    { icon: Target, label: "Quotas" },
    { icon: MessageSquare, label: "Logs" },
    { icon: ShieldCheck, label: "Roles" },
    { icon: Code, label: "Tracking" },
  ];

  return (
    <div className="landing-body min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* ------------------------------------------------------------- banner */}
      <SiteBanner placement="marketing" />

      {/* ---------------------------------------------------------------- nav */}
      <nav className="sticky top-0 z-50 bg-background/70 backdrop-blur-xl border-b border-border/40">
        <div className="max-w-[1180px] mx-auto px-6 h-[68px] flex items-center justify-between">
          <div className="flex items-center gap-9">
            <Wordmark />
            <div className="hidden md:flex items-center gap-7">
              <a href="#product" className="story-link text-[14px] font-medium text-muted-foreground hover:text-foreground">Product</a>
              <button onClick={() => navigate("/pricing")} className="story-link text-[14px] font-medium text-muted-foreground hover:text-foreground">Pricing</button>
              <button onClick={() => navigate("/feedback")} className="story-link text-[14px] font-medium text-muted-foreground hover:text-foreground">Ideas & bug reports</button>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} aria-label="Toggle theme" className="p-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-all">
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            {!isLoggedIn && (
              <button onClick={() => navigate("/login")} className="hidden sm:block text-[14px] font-medium px-4 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-all">
                Sign in
              </button>
            )}
            <button
              onClick={go}
              className="text-[14px] font-semibold h-10 px-5 rounded-lg text-white hover:brightness-110 hover:scale-[1.03] active:scale-[0.98] transition-all"
              style={{ background: "#2f74a8" }}
            >
              {isLoggedIn ? "Dashboard" : "Sign up"}
            </button>
          </div>
        </div>
      </nav>

      {/* --------------------------------------------------------------- hero */}
      <section className="relative overflow-hidden">
        {/* gradient under headline */}
        <div
          className="pointer-events-none absolute left-0 top-[18%] w-full h-[420px] opacity-60 blur-3xl"
          style={{
            background:
              "radial-gradient(ellipse 90% 55% at 30% 60%, rgba(47,116,168,0.45) 0%, rgba(47,116,168,0.18) 45%, transparent 75%)",
          }}
          aria-hidden="true"
        />

        <div className="relative max-w-[1180px] mx-auto px-6 pt-20 sm:pt-28 pb-2">
          <div className="stagger-fade">
            <h1 className="landing-head text-[44px] sm:text-[64px] lg:text-[76px] font-bold leading-[1.02] max-w-[16ch]">
              Run your staff team like an actual company.
            </h1>
            <p className="mt-7 text-[17px] leading-[1.7] text-muted-foreground max-w-[54ch]">
              Fluxcore keeps activity, ranking, sessions, quotas and policies in one place —
              wired straight into your Roblox group and your Discord server.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-3.5">
              <button
                onClick={go}
                className="group h-12 px-7 rounded-lg text-white text-[15px] font-semibold inline-flex items-center gap-2 hover:brightness-110 hover:scale-[1.03] active:scale-[0.98] transition-all"
                style={{ background: "#2f74a8", boxShadow: "0 12px 36px -12px rgba(47,116,168,0.55)" }}
              >
                {isLoggedIn ? "Open dashboard" : "Get started — it's free"}
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
              <button onClick={() => navigate("/demo")} className="h-12 px-7 rounded-lg border border-border text-[15px] font-medium inline-flex items-center gap-2.5 hover:bg-muted/50 hover:border-border/80 transition-all">
                Try the live demo
              </button>
              <button onClick={() => navigate("/pricing")} className="h-12 px-7 rounded-lg border border-border text-[15px] font-medium inline-flex items-center gap-2.5 hover:bg-muted/50 hover:border-border/80 transition-all">
                Pricing
              </button>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------- product shot */}
        <div id="product" className="relative max-w-[1180px] mx-auto px-6 pt-16 sm:pt-20 animate-fade-up" style={{ animationDelay: "0.25s", animationFillMode: "backwards" }}>
          {isMobile ? <NexusPhone rail={rail} /> : <NexusWindow rail={rail} />}
          <div className="mt-4 text-center">
            <button onClick={() => navigate("/demo")} className="text-[14px] font-medium story-link" style={{ color: "#2f74a8" }}>
              Open the interactive demo →
            </button>
          </div>
        </div>


      </section>

      {/* --------------------------------------------------------------- used */}
      <section className="pt-24 pb-4">
        <div className="max-w-[1180px] mx-auto px-6">
          <div className="border-t border-border/50 pt-10">
            <p className="landing-head text-[22px] sm:text-[26px] font-bold text-foreground mb-2">
              Trusted By
            </p>
            <p className="text-[14.5px] text-muted-foreground leading-[1.7] max-w-[58ch] mb-7">
              Groups running daily shifts, trainings and rank changes on Fluxcore — with their
              activity, logbooks and quotas handled in one place instead of five bots.
            </p>
            <div className="flex items-center gap-4 flex-wrap mb-11">
              <span className="flex items-center gap-2.5 rounded-lg border border-border/50 bg-card/40 pl-1.5 pr-5 py-1.5 hover-lift">
                <img src={bloxyBargainsBadge} alt="Bloxy Bargains" className="w-8 h-8 rounded-lg object-cover" />
                <span className="text-[14px] font-medium">Bloxy Bargains</span>
              </span>
              <span className="flex items-center gap-2.5 rounded-lg border border-border/50 bg-card/40 pl-1.5 pr-5 py-1.5 hover-lift">
                <img src={redFunnelBadge} alt="Red Funnel Group" className="w-8 h-8 rounded-lg object-cover" />
                <span className="text-[14px] font-medium">Red Funnel Group</span>
              </span>
            </div>
            <WorkspaceMarquee />
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------- pillars */}
      <section className="py-20">
        <div className="max-w-[1180px] mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { icon: Clock, t: "Tracked to the second", d: "A heartbeat every 30 seconds with idle detection, so in-game minutes are what actually happened — not what someone claims happened." },
              { icon: LayoutDashboard, t: "A dashboard you design", d: "Nexus UI 2.0 lets owners choose the cards, the rail and the hero. Every staff member sees the layout you shipped." },
              { icon: Zap, t: "Ranks that move themselves", d: "A logbook entry ranks the member in the Roblox group, updates their Fluxcore role and posts it to Discord — one action, three systems in sync." },
            ].map((c) => (
              <div key={c.t} className="rounded-xl border border-border/50 bg-card/30 p-8 hover-lift hover:border-[rgba(47,116,168,0.25)] group">
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6"
                  style={{ background: "rgba(47,116,168,0.10)", border: "1px solid rgba(47,116,168,0.15)" }}
                >
                  <c.icon className="w-[19px] h-[19px]" strokeWidth={1.9} style={{ color: "#2f74a8" }} />
                </div>
                <h3 className="landing-head text-[19px] font-bold mb-2.5">{c.t}</h3>
                <p className="text-[14.5px] text-muted-foreground leading-[1.7]">{c.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* -------------------------------------------------------- capabilities */}
      <section className="pb-24">
        <div className="max-w-[1180px] mx-auto px-6">
          <div className="border-t border-border/50 pt-12 mb-12 flex flex-wrap items-end justify-between gap-4">
            <h2 className="landing-head text-[30px] sm:text-[40px] font-bold leading-[1.08] max-w-[18ch]">
              Everything else your group already needs
            </h2>
            <p className="text-[14.5px] text-muted-foreground max-w-[36ch]">
              Twelve systems that usually live in five different bots and a spreadsheet.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 stagger-fade">
            {capabilities.map((c) => (
              <div key={c.title} className="rounded-lg border border-border/40 bg-card/20 p-6 flex gap-4 hover:bg-card/50 hover:border-[rgba(47,116,168,0.20)] hover:-translate-y-0.5 transition-all duration-300">
                <div className="w-9 h-9 rounded-lg bg-muted/60 border border-border/50 flex items-center justify-center shrink-0">
                  <c.icon className="w-[15px] h-[15px] text-muted-foreground" strokeWidth={1.9} />
                </div>
                <div>
                  <h3 className="landing-head text-[15.5px] font-semibold mb-1.5">{c.title}</h3>
                  <p className="text-[13.5px] text-muted-foreground leading-[1.65]">{c.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------------- security */}
      <section className="border-y border-border/50 bg-muted/20">
        <div className="max-w-[1080px] mx-auto px-6 py-20 grid lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] gap-12">
          <div>
            <h2 className="landing-head text-[30px] sm:text-[38px] font-bold leading-[1.1] mb-5">
              Your data is encrypted and never leaves our database.
            </h2>
            <p className="text-[15.5px] text-muted-foreground leading-[1.7]">
              Isolation happens in Postgres, not just in the app. Even if someone got a query through,
              one workspace still cannot read another&rsquo;s rows.
            </p>
          </div>

          <div className="rounded-xl border border-border/50 bg-card/30 p-2 sm:p-3">
            {[
              ["Encrypted in transit", "HTTPS/TLS 1.2+ with OCSP stapling on every request — browser, game server, Open Cloud."],
              ["Encrypted at rest", "Managed Postgres encrypts every disk page and every automated backup, uploads included."],
              ["Secrets double-encrypted", "API keys, Open Cloud keys and webhooks get a second pgcrypto layer. Owners only."],
              ["Row-Level Security", "Every table gated by RLS. Workspaces are isolated at the database level."],
              ["Roblox OAuth, no passwords", "OAuth 2.0 with PKCE. We never see or store a Roblox password."],
              ["Daily breach scans", "Automated checks for faults and exposure run every night, reviewed by staff."],
            ].map(([t, d], i, arr) => (
              <div key={t} className={`py-4 px-4 sm:px-5 flex gap-4 rounded-lg hover:bg-muted/40 transition-colors ${i < arr.length - 1 ? "border-b border-border/40" : ""}`}>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" strokeWidth={1.9} />
                </div>
                <div>
                  <h3 className="landing-head text-[14.5px] font-semibold mb-1">{t}</h3>
                  <p className="text-[13.5px] text-muted-foreground leading-[1.6]">{d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------ pricing */}
      <section>
        <div className="max-w-[1080px] mx-auto px-6 py-20">
          <div className="rounded-xl border border-border/50 bg-card/30 p-9 sm:p-12 flex flex-col md:flex-row md:items-center gap-8 justify-between hover:border-[rgba(47,116,168,0.25)] transition-colors duration-500">
            <div className="max-w-[46ch]">
              <p className="landing-head text-[12px] font-semibold uppercase tracking-[0.16em] text-muted-foreground mb-4">Pricing</p>
              <h2 className="landing-head text-[30px] font-bold leading-[1.1] mb-3">Free for everyone. Forever.</h2>
              <p className="text-[15.5px] text-muted-foreground leading-[1.7]">
                No card and no subscription. Every feature is unlocked for every group,
                whether you have nine staff or nine hundred.
              </p>
            </div>
            <div className="shrink-0">
              <button
                onClick={go}
                className="group inline-flex items-center gap-2 h-12 px-7 rounded-lg text-white text-[15px] font-semibold hover:scale-[1.04] active:scale-[0.98] transition-transform"
                style={{ background: "#2f74a8" }}
              >
                {isLoggedIn ? "Open dashboard" : "Create your workspace"}
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------- footer */}
      <footer className="border-t border-border/50">
        <div className="max-w-[1080px] mx-auto px-6 py-14 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Wordmark small />
            <p className="mt-3.5 text-[13.5px] text-muted-foreground leading-[1.65] max-w-[28ch]">
              Staff management for Roblox groups that take it seriously.
            </p>
          </div>
          {[
            { h: "Product", l: [["Pricing", "/pricing"], ["Security", "/security"], ["Status", "/status"], ["Ideas & bug reports", "/feedback"]] },
            { h: "Support", l: [["Help & tickets", "/support"], ["Feedback", "/feedback"], ["Workspaces", "/workspaces"]] },
            { h: "Legal", l: [["Terms", "/terms"], ["Privacy", "/privacy"]] },
          ].map((col) => (
            <div key={col.h}>
              <h4 className="landing-head text-[12px] font-semibold uppercase tracking-[0.14em] text-muted-foreground mb-4">{col.h}</h4>
              <ul className="space-y-2.5">
                {col.l.map(([label, href]) => (
                  <li key={label}>
                    <button onClick={() => navigate(href)} className="text-[13.5px] text-muted-foreground hover:text-foreground transition-colors">
                      {label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-border/50">
          <div className="max-w-[1080px] mx-auto px-6 py-5 text-[12.5px] text-muted-foreground flex flex-wrap gap-2 justify-between">
            <span>&copy; {new Date().getFullYear()} Fluxcore. All rights reserved to RetailPro Technologies UIA.</span>
            <span>Not affiliated with or endorsed by Roblox Corporation.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Nexus UI render — mirrors the real BargainsShell chrome                     */
/* -------------------------------------------------------------------------- */

type RailItem = { icon: LucideIcon; label: string };

function NexusWindow({ rail }: { rail: RailItem[] }) {
  return (
    <div className="rounded-2xl border border-border/60 overflow-hidden shadow-[0_32px_80px_-32px_rgba(0,0,0,0.6)] hover:shadow-[0_40px_90px_-32px_rgba(47,116,168,0.25)] transition-shadow duration-700" style={{ background: "#0f0f10" }}>
      {/* browser chrome */}
      <div className="flex items-center gap-1.5 px-3.5 py-2.5 border-b" style={{ borderColor: "#1a1a1c", background: "#0a0a0b" }}>
        <span className="w-2.5 h-2.5 rounded-full" style={{ background: "#3a3a3e" }} />
        <span className="w-2.5 h-2.5 rounded-full" style={{ background: "#3a3a3e" }} />
        <span className="w-2.5 h-2.5 rounded-full" style={{ background: "#3a3a3e" }} />
        <div className="flex-1 flex justify-center">
          <div className="px-3.5 py-1 rounded-full text-[11px] font-mono" style={{ background: "#161618", color: "rgba(255,255,255,0.45)" }}>
            fluxcore.works/w/staff-team/dashboard
          </div>
        </div>
      </div>

      <img
        src={nexusDemoShot}
        alt="Fluxcore Nexus workspace dashboard showing staff roster, sessions and activity"
        className="block w-full"
        loading="lazy"
      />
    </div>
  );
}

function NexusPhone({ rail }: { rail: RailItem[] }) {
  return (
    <div className="mx-auto w-[272px] rounded-[1.5rem] border-[6px] border-[#1a1a1c] overflow-hidden shadow-[0_32px_70px_-30px_rgba(0,0,0,0.65)]" style={{ background: "#0f0f10" }}>
      <div className="h-6 flex items-center justify-center" style={{ background: "#0a0a0b" }}>
        <div className="w-16 h-3 rounded-full" style={{ background: "#0f0f10" }} />
      </div>
      <div style={{ color: "#fafafa" }}>
        <div className="h-11 px-3 flex items-center justify-between border-b" style={{ background: "#0a0a0b", borderColor: "#1a1a1c" }}>
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-md" style={{ background: "#f55a4a" }} />
            <span className="text-[12px] font-semibold">Staff Team</span>
          </div>
          <span className="text-[10px]" style={{ color: "#6f6f74" }}>Dashboard</span>
        </div>
        <div className="p-3 space-y-3">
          <div className="rounded-xl h-[88px] p-3 flex flex-col justify-end" style={{ background: "linear-gradient(135deg,#6ea8ff 0%,#88b8ff 42%,#b6d2ff 100%)" }}>
            <div className="text-[8px] font-semibold uppercase tracking-wider text-white/85">Hiya</div>
            <div className="text-white text-[15px] font-bold leading-tight">Novavoff</div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[["Online now", "8"], ["Hours today", "142h"]].map(([l, v]) => (
              <div key={l} className="rounded-xl border p-2.5" style={{ background: "#141416", borderColor: "#22222a" }}>
                <div className="text-[8px] uppercase tracking-wider" style={{ color: "#6f6f74" }}>{l}</div>
                <div className="text-lg font-bold leading-tight">{v}</div>
              </div>
            ))}
          </div>
          {[["synt", "Promoted to Supervisor"], ["kai", "Signed Staff Handbook"], ["mira", "Logged 6h in-game"]].map(([n, a]) => (
            <div key={n} className="flex items-center gap-2 rounded-xl border px-2.5 py-2" style={{ background: "#141416", borderColor: "#22222a" }}>
              <span className="w-6 h-6 rounded-full shrink-0" style={{ background: "linear-gradient(135deg,#4d4d55,#2a2a30)" }} />
              <div className="min-w-0">
                <div className="text-[10px] font-semibold">{n}</div>
                <div className="text-[9px] truncate" style={{ color: "#6f6f74" }}>{a}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-around border-t py-2" style={{ background: "#0a0a0b", borderColor: "#1a1a1c" }}>
          {rail.slice(0, 5).map((i, idx) => (
            <i.icon key={i.label} className="w-[16px] h-[16px]" strokeWidth={1.8} />
          ))}
        </div>
      </div>
    </div>
  );
}
